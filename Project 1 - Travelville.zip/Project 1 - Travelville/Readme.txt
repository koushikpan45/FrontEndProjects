This Project contains the files of Travelville website which is a travelling website, created with Materialize CSS
